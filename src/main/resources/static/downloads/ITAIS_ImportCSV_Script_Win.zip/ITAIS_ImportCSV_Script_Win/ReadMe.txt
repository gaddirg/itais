GetInventoryWin.vbs
--------------------------

Functionality: 
	- Extract information from local machine and other machine within the network.
Requirements: 
	- Windows machine only 
	- administrator privilege to extract infrom local machine
	- domain administrator privilege to extract info from machines within the network  
How to use:
	- Sign-in as administrator
	- Input all the computer names of the machines you want to import in the machines.txt 
	- Double-click the script
Output:
	- MachineInventory.csv
	- Use this file to upload in ITAIS