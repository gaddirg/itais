GetInventoryWin.vbs
--------------------------

Functionality: 
	- Extract information from local machine and other machine within the network.
Requirements: 
	- Windows machine only 
	- administrator privilege to extract infrom local machine
	- domain administrator privilege to extract info from machines within the network  
How to use:
	- Sign-in as administrator
	- Double-click the script
Output:
	- MachineInventory.csv
	- Use this file to upload in ITAIS